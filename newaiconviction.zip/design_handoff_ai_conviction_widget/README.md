# Handoff: AI Conviction Widget

## Overview
A compact, single-row data widget for a holdings/trading terminal that summarizes the
**AI Conviction** for a stock (or watchlist item) based on a set of analyzed stories.
It shows three things side by side:

1. An **AI Conviction score** (a percentage) with a brain icon.
2. The **total number of stories** analyzed.
3. A **horizontal bar chart** breaking those stories into **Buy / Hold / Sell**
   sentiment, where each bar's length encodes its magnitude.

The widget is dark-themed, monospace, and intentionally dense — it is meant to live
inside a terminal-style dashboard, not as a standalone hero element.

## About the Design Files
The file in this bundle (`conviction-widget.html`) is a **design reference created in
HTML/CSS/JS** — a prototype showing the intended look and behavior. It is **not
production code to copy directly**. The task is to **recreate this design in the target
codebase's existing environment** (React, Vue, Svelte, SwiftUI, etc.) using that
codebase's established component patterns, styling system, and charting/layout
primitives. If no front-end environment exists yet, choose the most appropriate
framework for the project and implement it there.

The prototype renders the widget **twice** (Variant A and Variant B) purely to
demonstrate that the layout is fully data-driven — in production this is **one
reusable component** that takes data as props.

## Fidelity
**High-fidelity (hifi).** Colors, typography, spacing, and the bar-scaling math are
final and should be matched precisely. Recreate the UI pixel-for-pixel using the
codebase's existing libraries and patterns.

## Screens / Views

### Screen: AI Conviction Widget (single component)
- **Name**: AI Conviction Widget
- **Purpose**: Give the user an at-a-glance read on aggregate AI sentiment for a
  holding — the conviction score, how many stories informed it, and the Buy/Hold/Sell
  split.
- **Layout**: A single horizontal row (`display:flex; align-items:center`) inside a
  rounded panel ("shell"). Three columns separated by gaps, left → right:
  1. **Score block** — fixed width, right-bordered divider.
  2. **Total block** — fixed width (`flex-shrink:0`).
  3. **Bar chart** — fills remaining space (`flex:1`).
  - Shell: `width: 496px`, `border-radius: 8px`, `1px` border, drop shadow.
  - Inner panel padding: `8px 16px`. Column gap: `15px`.

#### Component 1 — Score block (left)
- Vertical stack, **center-aligned** (`flex-direction:column; align-items:center;
  justify-content:center; gap:3px`). Right padding `15px`, with a `1px` right border
  acting as a divider.
- **Top row** (`.score__top`): centered flex row, `gap:7px`, containing:
  - **Brain icon** — Material Symbols Outlined, ligature name `neurology`. Rendered in
    a fixed `20×20px` box, `font-size:19px`, color = positive green `#22c55e`. In a real
    codebase, substitute the app's own brain/neuro icon at ~19–20px; color it green.
  - **Score percentage** — e.g. `25%`. `font-size:20px`, `font-weight:800`, color
    `#22c55e`, `font-variant-numeric: tabular-nums`.
  - The icon + percentage must always sit centered as a row **above** the label.
- **Label** (`.score__label`): the text `AI Conviction`, uppercased via CSS.
  `font-size:8.5px`, `font-weight:800`, `letter-spacing:0.15em`,
  `text-transform:uppercase`, color muted `#64748b`, `white-space:nowrap`.

#### Component 2 — Total block (middle)
- Vertical stack, left-aligned (`flex-direction:column; text-align:left;
  flex-shrink:0`).
- **Total number** (`.total__num`): sum of buy+hold+sell, e.g. `101`. `font-size:27px`,
  `font-weight:800`, color `#e2e2e6`, `letter-spacing:-0.01em`, tabular-nums.
- **Caption** (`.total__cap`): the word `stories`, uppercased. `margin-top:2px`,
  `font-size:8.5px`, `font-weight:700`, `letter-spacing:0.18em`,
  `text-transform:uppercase`, color `#64748b`.

#### Component 3 — Bar chart (right)
- Flex row (`gap:12px`): a thin **vertical axis line** then the **bars column**.
- **Axis** (`.axis`): `width:2px`, full height (`align-items:stretch`),
  background `rgba(255,255,255,0.16)`, `border-radius:1px`. The bars grow rightward out
  of this line.
- **Bars column** (`.bars`): vertical stack, centered, `gap:5px`. Three rows, in order
  **Buy, Hold, Sell**.
- **Bar row** (`.bar-row`): flex row, `align-items:center`, `gap:9px` — the colored bar
  followed by its numeric value.
  - **Bar** (`.bar`): `height:7px`, `border-radius:0 999px 999px 0` (flat left edge
    against the axis, rounded right end), `min-width:3px`,
    `transition:width .35s ease`. Width is computed (see Bar-scaling math).
  - **Value** (`.bar-val`): the raw count, `font-size:11px`, `font-weight:700`,
    tabular-nums, `flex-shrink:0`, colored to match its bar.
- **Bar colors**:
  - Buy: `#2ee37e` (bright green)
  - Hold: `rgba(139,151,168,0.75)` (muted slate; solid token `#8b97a8`)
  - Sell: `#ff5247` (red)

## Interactions & Behavior
- **Static display component** — no click handlers, navigation, or hover states in the
  current design.
- **Bar width animation**: bars have `transition: width .35s ease`. If the underlying
  data updates live, bars should animate to their new width. On initial mount this can
  optionally animate from `0` to the target width.
- No loading/error states are defined. If the source data can be pending, add a skeleton
  or empty state consistent with the host app.
- **Responsive**: the prototype uses a fixed `496px` shell. In production, allow the
  bar-chart column to flex while keeping the score and total columns at intrinsic width.
  The component is designed for a single row and is not intended to wrap.

## Bar-scaling math (important)
Bars are scaled **relative to the largest segment**, not to the total:

```
total = buy + hold + sell
max   = Math.max(buy, hold, sell)
MAX_FILL = 82            // the biggest bar fills 82% of the bars-column width
barWidthPercent = (value / max) * MAX_FILL
```

So the largest of the three bars is always `82%` wide, and the other two are scaled
proportionally. `MAX_FILL` is 82 (not 100) to leave room for the numeric value printed
at the end of the longest bar. `min-width: 3px` guarantees even a `0`/tiny segment
remains visible. The **conviction score percentage is NOT derived** from these counts in
the current design — it is passed in explicitly as its own value.

## State Management
The component is presentational. It takes one data object as input:

```ts
interface ConvictionData {
  score: number;  // AI conviction percentage, e.g. 25  → rendered "25%"
  buy:   number;  // # of buy-sentiment stories
  hold:  number;  // # of hold-sentiment stories
  sell:  number;  // # of sell-sentiment stories
}
```

Derived inside the component: `total = buy + hold + sell`, `max`, and each bar's width.
No internal state beyond that; if data updates, the width transition handles the
animation.

### Sample data (from the prototype)
- **Variant A · bullish**: `{ score: 25, buy: 49, hold: 42, sell: 10 }` → total `101`
- **Variant B · bearish**: `{ score: 9,  buy: 12, hold: 28, sell: 74 }` → total `114`

## Design Tokens

### Colors
| Token | Value | Use |
|---|---|---|
| `--bg-page` | `#0a0c0f` | page background (with radial gradient overlay) |
| `--bg-panel` | `rgba(0,0,0,0.35)` | widget inner panel background |
| `--border` | `rgba(255,255,255,0.06)` | shell border + internal dividers |
| `--txt` | `#e2e2e6` | primary text (total number) |
| `--muted` | `#64748b` | labels / captions |
| `--muted-dim` | `#475569` | variant captions, faint text |
| `--pos` | `#22c55e` | brain icon + score percentage (green) |
| `--buy` | `#2ee37e` | buy bar + buy value |
| `--hold` | `#8b97a8` | hold bar (used at 0.75 alpha) + hold value |
| `--sell` | `#ff5247` | sell bar + sell value |
| axis line | `rgba(255,255,255,0.16)` | vertical axis |

### Typography
- **Font family**: `JetBrains Mono` (monospace), weights 400/500/700/800. Fallback stack:
  `ui-monospace, 'SF Mono', Menlo, monospace`. Substitute the codebase's monospace face
  if one is already established.
- **Icon font**: Material Symbols Outlined (brain = `neurology`). Replace with the app's
  own icon set.
- Numerals use `font-variant-numeric: tabular-nums` everywhere for alignment.

### Type scale used
| Element | Size | Weight | Tracking | Transform |
|---|---|---|---|---|
| Total number | 27px | 800 | -0.01em | — |
| Score % | 20px | 800 | 0.01em | — |
| Brain icon | 19px | — | — | — |
| Bar value | 11px | 700 | — | — |
| Score label / total caption | 8.5px | 800 / 700 | 0.15–0.18em | uppercase |
| Variant caption | 9px | 400 | 0.22em | uppercase |

### Spacing
- Shell width: `496px`; border-radius `8px`.
- Panel padding: `8px 16px`.
- Column gap (score / total / chart): `15px`.
- Score block: inner gap `3px`, right padding `15px`.
- Bar chart: axis-to-bars gap `12px`; bar rows gap `5px`; bar-to-value gap `9px`.

### Other
- Border radius: shell `8px`, bars `0 999px 999px 0` (pill on the right end only),
  axis `1px`.
- Shadow: `0 20px 50px -20px rgba(0,0,0,0.8)`.
- Bar height: `7px`; axis width: `2px`.
- Bar transition: `width .35s ease`.

## Assets
- **Brain icon**: Material Symbols Outlined ligature `neurology` (loaded from Google
  Fonts in the prototype). Use the host app's existing icon library equivalent.
- **Fonts**: JetBrains Mono + Material Symbols Outlined via Google Fonts. No raster
  image or SVG assets are required.

## Files
- `conviction-widget.html` — the design reference (self-contained HTML/CSS/JS). The
  `buildWidget(data)` function at the bottom is the canonical source for the markup
  structure and the bar-scaling math.
